export enum Tags {
  LifeStyle = 'lifestyle',
  Mobile = 'mobile',
  Motor = 'motor',
  Work = 'work',
}
